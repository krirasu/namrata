package com.cg.mpa.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.mpa.dto.Mobile;
import com.cg.mpa.dto.PurchaseDetails;
import com.cg.mpa.exception.MobileException;
import com.cg.mpa.util.DBUtil;

public class MobilePurchaseDaoImpl implements MobilePurchaseDao {
	Connection conn=null;
	@Override
	public List<Mobile> getAllMobiles() throws MobileException 
	{
		List<Mobile>mlist=new ArrayList<>();
		conn=DBUtil.getConnection();
		try
		{
		Statement st=conn.createStatement();
		ResultSet rst=st.executeQuery(QueryMapper.SELECT_ALL_MOBILES);
		while(rst.next())
		{
			Mobile m=new Mobile();
			m.setMobileId(rst.getLong("mobileid"));
			m.setMobName(rst.getString("name"));
			m.setPrice(rst.getFloat("price"));
			m.setQty(rst.getInt("quantity"));
			mlist.add(m);
			
		}
		}
		catch(SQLException e)
		{
			throw new MobileException ("Problem in fetching mobile list:"+e.getMessage());
		}
		return mlist;
	}

	@Override
	public Mobile getMobile(long mid) throws MobileException
	{
		conn=DBUtil.getConnection();
		Mobile m=null;
		PreparedStatement pst;
		try {
			pst = conn.prepareStatement(QueryMapper.SELECT_MOBILE);
			pst.setLong(1,mid);
			ResultSet rs=pst.executeQuery();
			if(rs.next())
			{
				m=new Mobile();
				m.setMobileId(rs.getLong("mobileid"));
				m.setMobName(rs.getString("name"));
				m.setPrice(rs.getFloat("price"));
				m.setQty(rs.getInt("quantity"));
			}
			else
			{
				throw new MobileException("Mobile not found");
			}
		} 
		catch (SQLException e)
		{
			throw new MobileException("Problem in fetching mobile: "+e.getMessage());
		
		}
		
		return m;
	}
	
	private long generatePurchaseId()throws MobileException
	{
		long pid=0;
		conn=DBUtil.getConnection();
		try
		{
			Statement st=conn.createStatement();
			ResultSet rs=st.executeQuery(QueryMapper.SELECT_SEQUENCE);
			rs.next();
			pid=rs.getLong(1);
		}
		catch(SQLException e)
		{
			throw new MobileException("Problem in generating purchase id"+e.getMessage());
		}
		return pid;
	}

	@Override
	public long insertPurchaseDetails(PurchaseDetails pDetails)throws MobileException
	{
		conn=DBUtil.getConnection();
		pDetails.setPurchaseId(generatePurchaseId());
		try
		{
			PreparedStatement pst=conn.prepareStatement(QueryMapper.INSERT_QUERY);
			pst.setLong(1, pDetails.getPurchaseId());
			pst.setString(2, pDetails.getCustName());
			pst.setString(3, pDetails.getMailId());
			pst.setLong(4, pDetails.getPhoneNo());
			pst.setDate(5, Date.valueOf(pDetails.getPurchaseDate()));
			pst.setLong(6, pDetails.getMobileId());
			pst.executeUpdate();
		} 
		catch (SQLException e) 
		{
			throw new MobileException("Problem in inserting details"+e.getMessage());
		}
		
		return pDetails.getPurchaseId();
	}

}
