package com.cg.mpa.dao;

public interface QueryMapper 
{
	String INSERT_QUERY="INSERT INTO purchasedetails VALUES(?,?,?,?,?,?)";
	String SELECT_ALL_MOBILES="SELECT mobileId,name,price,quantity FROM mobiles";
	String SELECT_SEQUENCE="SELECT pur_seq.NEXTVAL FROM dual";
	String SELECT_MOBILE="SELECT mobileId,name,price,quantity FROM mobiles WHERE mobileid=?";
}
