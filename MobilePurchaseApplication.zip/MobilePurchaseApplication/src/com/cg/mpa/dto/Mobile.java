package com.cg.mpa.dto;

public class Mobile 
{
	private long mobileId;
	private String mobName;
	private float price;
	private int qty;
	public long getMobileId() {
		return mobileId;
	}
	public void setMobileId(long mobileId) {
		this.mobileId = mobileId;
	}
	public String getMobName() {
		return mobName;
	}
	public void setMobName(String mobName) {
		this.mobName = mobName;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	@Override
	public String toString() {
		return "Mobile [mobileId=" + mobileId + ", mobName=" + mobName
				+ ", price=" + price + ", qty=" + qty + "]";
	}
	public Mobile(int mobileId, String mobName, float price, int qty) {
		super();
		this.mobileId = mobileId;
		this.mobName = mobName;
		this.price = price;
		this.qty = qty;
	}
	public Mobile() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
