package com.cg.mpa.service;

import java.util.List;

import com.cg.mpa.dao.MobilePurchaseDao;
import com.cg.mpa.dao.MobilePurchaseDaoImpl;
import com.cg.mpa.dto.Mobile;
import com.cg.mpa.dto.PurchaseDetails;
import com.cg.mpa.exception.MobileException;

public class MobilePurchaseServiceImpl implements MobilePurchaseService
{
	MobilePurchaseDao mDao=new MobilePurchaseDaoImpl();
	@Override
	public List<Mobile> getAllMobiles() throws MobileException
	{
		return mDao.getAllMobiles();
	}

	@Override
	public Mobile getMobile(long mid) throws MobileException
	{
		return mDao.getMobile(mid);
	}

	@Override
	public long insertPurchaseDetails(PurchaseDetails pDetails)throws MobileException
	{
		return mDao.insertPurchaseDetails(pDetails);
	}

}
