package com.cg.mpa.util;

import java.sql.Connection;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.cg.mpa.exception.MobileException;

public class DBUtil 
{
	public static Connection getConnection() throws MobileException
	{
		Connection con=null;
		InitialContext context;
	    try 
	    {
			context=new InitialContext();
			DataSource ds=(DataSource)context.lookup("java:/jdbc/OracleDS");
			con=ds.getConnection();
		} 
	    catch (Exception e) 
	    {
			throw new MobileException(e.getMessage());
		}	
			return con;
		}

	
	}
